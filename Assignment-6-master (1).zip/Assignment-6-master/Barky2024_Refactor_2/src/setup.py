from setuptools import setup

setup(
    name="barky",
    version="0.1.0",
    packages=["barky", "djbarky"],
)
