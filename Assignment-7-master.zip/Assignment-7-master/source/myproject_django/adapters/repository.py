# repository.py

from django.core.exceptions import ObjectDoesNotExist
from .models import Bookmark

class BookmarkRepository:
    def __init__(self, model=Bookmark):
        self.model = model

    def add(self, bookmark):
        bookmark.save()

    def get(self, bookmark_id):
        try:
            return self.model.objects.get(id=bookmark_id)
        except ObjectDoesNotExist:
            return None

    def list(self):
        return list(self.model.objects.all())

    def remove(self, bookmark_id):
        bookmark = self.get(bookmark_id)
        if bookmark:
            bookmark.delete()
        else:
            raise ValueError("Bookmark with id {bookmark_id} does not exist.")

    def update(self, bookmark_id, new_data):
        bookmark = self.get(bookmark_id)
        if bookmark:
            for key, value in new_data.items():
                setattr(bookmark, key, value)
            bookmark.save()
            return bookmark
        else:
            raise ValueError("Bookmark with id {bookmark_id} does not exist.")
