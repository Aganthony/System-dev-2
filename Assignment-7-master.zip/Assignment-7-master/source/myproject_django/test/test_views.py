# test_views.py
from django.urls import reverse
from django.test import TestCase

class BookmarkViewTest(TestCase):
    def test_create_bookmark(self):
        response = self.client.post(reverse('create-bookmark'), data={
            'title': 'Test Bookmark',
            'url': 'http://example.com',
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Bookmark created')
