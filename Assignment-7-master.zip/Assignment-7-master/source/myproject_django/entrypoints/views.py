# views.py
from django.shortcuts import render
from service_layer import message_bus
from source.myproject_django.domain.commands import CreateBookmarkCommand

def create_bookmark(request):
    # Convert request data into a command
    command = CreateBookmarkCommand(
        title=request.POST['title'],
        url=request.POST['url'],
        notes=request.POST.get('notes', '')
    )
    # Use the message bus to handle the command
    message_bus.handle(command)
    return render(request, 'bookmark_created.html')
