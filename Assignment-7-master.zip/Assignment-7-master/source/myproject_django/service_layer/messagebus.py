# message_bus.py

class MessageBus:
    def __init__(self, uow, command_handlers):
        self.uow = uow
        self.command_handlers = command_handlers
    
    def handle(self, command):
        with self.uow:
            self.command_handlers[type(command)](command)
            self.uow.commit()
