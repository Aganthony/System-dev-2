# events.py

class Event:
    pass

class BookmarkCreatedEvent(Event):
    def __init__(self, bookmark):
        self.bookmark = bookmark
