# unit_of_work.py
from contextlib import contextmanager
from django.db import transaction

class DjangoUnitOfWork:
    @contextmanager
    def __call__(self):
        with transaction.atomic():
            yield
