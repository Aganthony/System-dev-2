# handlers.py

def handle_bookmark_created_event(event):
    # Logic to respond to the bookmark creation
    print(f"Bookmark created: {event.bookmark.title}")
