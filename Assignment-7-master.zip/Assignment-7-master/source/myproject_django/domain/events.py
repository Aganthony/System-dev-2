# events.py

class Event:
    pass

class BookmarkCreatedEvent(Event):
    def __init__(self, bookmark_id, title):
        self.bookmark_id = bookmark_id
        self.title = title


