# models.py

class Bookmark:
    def __init__(self, title, url, notes=None):
        self.title = title
        self.url = url
        self.notes = notes
        self.events = []
